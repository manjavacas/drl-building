energym.utils.common.parse\_observation\_action\_space
======================================================

.. currentmodule:: energym.utils.common

.. autofunction:: parse_observation_action_space