
.. include:: pages/introduction.rst

.. toctree::
   :maxdepth: 2
   :hidden:

   pages/installation.rst
   pages/environments.rst
   pages/tests.rst
   pages/usage-example.rst
   pages/output.rst
   pages/API-reference.rst











